package modelo;

public class AutonomiaException extends Exception {
    public AutonomiaException(String mensaje) {
        super(mensaje);
    }
}
